--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4 (Debian 14.4-1.pgdg110+1)
-- Dumped by pg_dump version 14.4 (Debian 14.4-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webpage_hit_counter;
--
-- Name: webpage_hit_counter; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE webpage_hit_counter WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE webpage_hit_counter OWNER TO admin;

\connect webpage_hit_counter

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hit_counter; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.hit_counter (
    id integer NOT NULL,
    webpage_id integer NOT NULL,
    count integer NOT NULL
);


ALTER TABLE public.hit_counter OWNER TO admin;

--
-- Name: hit_counter_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.hit_counter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hit_counter_id_seq OWNER TO admin;

--
-- Name: hit_counter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.hit_counter_id_seq OWNED BY public.hit_counter.id;


--
-- Name: webpage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.webpage (
    id integer NOT NULL,
    webpage text NOT NULL
);


ALTER TABLE public.webpage OWNER TO admin;

--
-- Name: hit_counter id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter ALTER COLUMN id SET DEFAULT nextval('public.hit_counter_id_seq'::regclass);


--
-- Data for Name: hit_counter; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.hit_counter (id, webpage_id, count) FROM stdin;
\.
COPY public.hit_counter (id, webpage_id, count) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: webpage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.webpage (id, webpage) FROM stdin;
\.
COPY public.webpage (id, webpage) FROM '$$PATH$$/3316.dat';

--
-- Name: hit_counter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.hit_counter_id_seq', 4, true);


--
-- Name: hit_counter hit_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter
    ADD CONSTRAINT hit_counter_pkey PRIMARY KEY (id);


--
-- Name: webpage webpage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.webpage
    ADD CONSTRAINT webpage_pkey PRIMARY KEY (id);


--
-- Name: hit_counter webpage; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hit_counter
    ADD CONSTRAINT webpage FOREIGN KEY (webpage_id) REFERENCES public.webpage(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

